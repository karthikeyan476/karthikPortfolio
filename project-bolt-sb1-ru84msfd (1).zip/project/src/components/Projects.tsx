import React, { useState } from 'react';
import { ExternalLink, BarChart, Database, Code, Cloud } from 'lucide-react';

const Projects: React.FC = () => {
  const [activeTab, setActiveTab] = useState('powerbi');

  const projectTabs = [
    { id: 'powerbi', label: 'Power BI', icon: BarChart },
    { id: 'tableau', label: 'Tableau', icon: Database },
    { id: 'python', label: 'Python', icon: Code },
    { id: 'azure', label: 'Azure', icon: Cloud }
  ];

  const projects = {
    powerbi: [
      {
        title: 'Healthcare Patient Details Dashboard',
        description: 'Comprehensive healthcare dashboard analyzing patient demographics, treatment outcomes, and medical history with interactive visualizations for clinical decision support.',
        image: 'https://images.pexels.com/photos/40568/medical-appointment-doctor-healthcare-40568.jpeg',
        technologies: ['Power BI', 'DAX', 'SQL Server', 'Azure'],
        liveUrl: 'https://app.powerbi.com/view?r=eyJrIjoiOGI3ZjRkYTAtMGIyZC00OGMwLWFmNDctMmRmOWYxZWUyZWEzIiwidCI6IjYwYjZhZDk4LTI4YWMtNDhhZi1hNmU5LWE0NTIwMjE5YjZmOCJ9'
      },
      {
        title: 'Loan Application Analytics',
        description: 'Advanced loan application dashboard providing insights into approval rates, risk assessment, and borrower profiles with predictive analytics for decision support.',
        image: 'https://images.pexels.com/photos/4386321/pexels-photo-4386321.jpeg',
        technologies: ['Power BI', 'DAX', 'RLS', 'Data Modeling'],
        liveUrl: 'https://app.powerbi.com/view?r=eyJrIjoiYTRhNjYwY2MtMDBhMi00NWZlLWJjZTctZDNmNWI0MTdlMGVmIiwidCI6IjYwYjZhZDk4LTI4YWMtNDhhZi1hNmU5LWE0NTIwMjE5YjZmOCJ9'
      }
    ],
    tableau: [
      {
        title: 'Campaign Analysis',
        description: 'Interactive campaign performance dashboard with comprehensive analytics, ROI tracking, and audience segmentation insights for data-driven marketing decisions.',
        image: 'https://images.pexels.com/photos/590016/pexels-photo-590016.jpeg',
        technologies: ['Tableau', 'Tableau Prep', 'PostgreSQL', 'Python'],
        liveUrl: 'https://public.tableau.com/app/profile/karthikeyan.subramanian4479/viz/CampaignAnalysisDashboard_17486864134760/LandingPage'
      }
    ],
    python: [
      {
        title: 'Data Processing',
        description: 'Advanced data processing pipeline using Python for ETL operations, data cleaning, transformation, and analysis with automated workflows and performance optimization.',
        image: 'https://images.pexels.com/photos/1181671/pexels-photo-1181671.jpeg',
        technologies: ['Python', 'Pandas', 'NumPy', 'Jupyter Notebook'],
        liveUrl: 'https://colab.research.google.com/drive/18N5fQjt3rZpv3FH1ctXPQXYc5_zSC3cA?usp=sharing'
      },
      {
        title: 'Customer Shopping Details',
        description: 'Comprehensive customer behavior analysis project examining shopping patterns, purchase trends, and customer segmentation using machine learning techniques.',
        image: 'https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg',
        technologies: ['Python', 'Scikit-learn', 'Matplotlib', 'Seaborn'],
        liveUrl: 'https://github.com/karthikeyan476/Customer_Shpping_Details'
      }
    ],
    azure: [
      {
        title: 'End-to-End Azure Data Engineering Pipeline',
        description: 'I successfully delivered an end-to-end Azure Data Engineering project, building a production-ready data pipeline that spanned the full data lifecycle. The project began with sourcing and ingesting data from GitHub into an Azure SQL Database. I implemented incremental data loading and handled Slowly Changing Dimensions (SCD Type 1) using Azure Data Factory, enabling a robust transition from raw (bronze) to cleaned and transformed (silver) data layers. In the transformation stage, I utilized Azure Databricks to develop a star schema model by decomposing a large source table into well-structured fact and dimension tables in the gold layer. I performed advanced PySpark transformations and leveraged Delta Lake capabilities for versioning, ACID transactions, and efficient storage. To ensure efficient and automated data operations, I orchestrated the workflow using Databricks jobs and task scheduling features. The final output was integrated with Power BI, where I developed interactive dashboards for business insights and decision-making. This project demonstrates my hands-on experience across the Azure data stack—including Data Factory, Databricks, Delta Lake, and Power BI—and my ability to design scalable, maintainable, and business-aligned data pipelines.',
        image: 'https://images.pexels.com/photos/325229/pexels-photo-325229.jpeg',
        technologies: ['Azure Data Factory', 'Azure Databricks', 'Delta Lake', 'PySpark', 'Power BI'],
        liveUrl: '#'
      }
    ]
  };

  return (
    <section id="projects" className="py-20 relative">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Featured Projects
          </h2>
          <p className="text-base text-gray-400 max-w-2xl mx-auto">
            Explore my portfolio of data solutions that drive business value and insights
          </p>
        </div>

        {/* Tab Navigation */}
        <div className="flex justify-center mb-12">
          <div className="flex bg-white/5 backdrop-blur-sm rounded-full p-2 border border-white/10">
            {projectTabs.map((tab) => {
              const IconComponent = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-6 py-3 rounded-full transition-all duration-300 ${
                    activeTab === tab.id
                      ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg'
                      : 'text-gray-400 hover:text-white hover:bg-white/10'
                  }`}
                >
                  <IconComponent className="w-5 h-5" />
                  <span className="hidden sm:inline">{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Project Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {projects[activeTab as keyof typeof projects].map((project, index) => (
            <div
              key={index}
              className="group relative"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              <div className="relative backdrop-blur-sm bg-white/5 border border-white/10 rounded-2xl overflow-hidden hover:bg-white/10 transition-all duration-300 hover:border-blue-400/30 hover:shadow-xl hover:shadow-blue-500/10">
                <div className="aspect-video relative overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 to-transparent"></div>
                </div>
                
                <div className="p-8">
                  <h3 className="text-xl font-bold text-white mb-3 group-hover:text-blue-400 transition-colors">
                    {project.title}
                  </h3>
                  <p className={`text-sm text-gray-400 mb-6 leading-relaxed`}>
                    {project.description}
                  </p>
                  
                  <div className="flex flex-wrap gap-2 mb-6">
                    {project.technologies.map((tech, techIndex) => (
                      <span
                        key={techIndex}
                        className="px-3 py-1 bg-blue-600/20 text-blue-300 rounded-full text-sm border border-blue-500/30"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                  
                  {/* Only show Live Demo button for non-Azure projects */}
                  {activeTab !== 'azure' && (
                    <div className="flex justify-center">
                      <a
                        href={project.liveUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:shadow-lg hover:shadow-blue-500/25 transition-all duration-300 transform hover:scale-105"
                      >
                        <ExternalLink className="w-4 h-4" />
                        Live Demo
                      </a>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;