import React, { useEffect, useState } from 'react';

interface FloatingElement {
  id: number;
  x: number;
  y: number;
  size: number;
  duration: number;
  delay: number;
  opacity: number;
  type: 'cube' | 'sphere' | 'pyramid' | 'torus';
}

interface DataNode {
  id: number;
  x: number;
  y: number;
  connections: number[];
  pulse: number;
}

interface BinaryStream {
  id: number;
  x: number;
  chars: string[];
  speed: number;
}

const FloatingElements: React.FC = () => {
  const [elements, setElements] = useState<FloatingElement[]>([]);
  const [dataNodes, setDataNodes] = useState<DataNode[]>([]);
  const [binaryStreams, setBinaryStreams] = useState<BinaryStream[]>([]);

  useEffect(() => {
    // Create 3D floating elements
    const createElements = () => {
      const newElements: FloatingElement[] = [];
      const types: FloatingElement['type'][] = ['cube', 'sphere', 'pyramid', 'torus'];
      
      for (let i = 0; i < 20; i++) {
        newElements.push({
          id: i,
          x: Math.random() * 100,
          y: Math.random() * 100,
          size: Math.random() * 40 + 20,
          duration: Math.random() * 30 + 20,
          delay: Math.random() * 10,
          opacity: Math.random() * 0.4 + 0.1,
          type: types[Math.floor(Math.random() * types.length)]
        });
      }
      setElements(newElements);
    };

    // Create neural network nodes
    const createDataNodes = () => {
      const nodes: DataNode[] = [];
      for (let i = 0; i < 12; i++) {
        const connections = [];
        const numConnections = Math.floor(Math.random() * 3) + 1;
        for (let j = 0; j < numConnections; j++) {
          const connectionId = Math.floor(Math.random() * 12);
          if (connectionId !== i && !connections.includes(connectionId)) {
            connections.push(connectionId);
          }
        }
        
        nodes.push({
          id: i,
          x: Math.random() * 90 + 5,
          y: Math.random() * 90 + 5,
          connections,
          pulse: Math.random() * 2
        });
      }
      setDataNodes(nodes);
    };

    // Create binary code streams
    const createBinaryStreams = () => {
      const streams: BinaryStream[] = [];
      for (let i = 0; i < 8; i++) {
        const chars = [];
        for (let j = 0; j < 20; j++) {
          chars.push(Math.random() > 0.5 ? '1' : '0');
        }
        
        streams.push({
          id: i,
          x: (i * 12.5) + Math.random() * 5,
          chars,
          speed: Math.random() * 3 + 2
        });
      }
      setBinaryStreams(streams);
    };

    createElements();
    createDataNodes();
    createBinaryStreams();

    // Update binary streams periodically
    const interval = setInterval(() => {
      setBinaryStreams(prev => prev.map(stream => ({
        ...stream,
        chars: stream.chars.map(() => Math.random() > 0.7 ? (Math.random() > 0.5 ? '1' : '0') : stream.chars[Math.floor(Math.random() * stream.chars.length)])
      })));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const get3DStyle = (element: FloatingElement) => {
    const baseStyle = {
      left: `${element.x}%`,
      top: `${element.y}%`,
      width: `${element.size}px`,
      height: `${element.size}px`,
      opacity: element.opacity,
      animation: `float3D ${element.duration}s linear infinite, rotate3D ${element.duration * 0.8}s linear infinite`,
      animationDelay: `${element.delay}s`
    };

    switch (element.type) {
      case 'cube':
        return {
          ...baseStyle,
          background: 'linear-gradient(45deg, rgba(14, 165, 233, 0.3), rgba(139, 92, 246, 0.3))',
          border: '1px solid rgba(14, 165, 233, 0.5)',
          transform: 'rotateX(45deg) rotateY(45deg)',
          boxShadow: '0 0 20px rgba(14, 165, 233, 0.3)'
        };
      case 'sphere':
        return {
          ...baseStyle,
          background: 'radial-gradient(circle at 30% 30%, rgba(20, 184, 166, 0.4), rgba(14, 165, 233, 0.2))',
          borderRadius: '50%',
          border: '1px solid rgba(20, 184, 166, 0.5)',
          boxShadow: '0 0 25px rgba(20, 184, 166, 0.4)'
        };
      case 'pyramid':
        return {
          ...baseStyle,
          background: 'linear-gradient(135deg, rgba(139, 92, 246, 0.3), rgba(236, 72, 153, 0.3))',
          clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)',
          border: '1px solid rgba(139, 92, 246, 0.5)',
          boxShadow: '0 0 20px rgba(139, 92, 246, 0.3)'
        };
      case 'torus':
        return {
          ...baseStyle,
          background: 'conic-gradient(from 0deg, rgba(14, 165, 233, 0.3), rgba(20, 184, 166, 0.3), rgba(139, 92, 246, 0.3), rgba(14, 165, 233, 0.3))',
          borderRadius: '50%',
          border: '3px solid transparent',
          backgroundClip: 'padding-box',
          boxShadow: 'inset 0 0 20px rgba(14, 165, 233, 0.3), 0 0 20px rgba(14, 165, 233, 0.2)'
        };
      default:
        return baseStyle;
    }
  };

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      {/* 3D Floating Elements */}
      {elements.map((element) => (
        <div
          key={element.id}
          className="absolute"
          style={get3DStyle(element)}
        />
      ))}

      {/* Neural Network Connections */}
      <svg className="absolute inset-0 w-full h-full" style={{ zIndex: 1 }}>
        {dataNodes.map((node) =>
          node.connections.map((connectionId) => {
            const targetNode = dataNodes[connectionId];
            if (!targetNode) return null;
            
            return (
              <line
                key={`${node.id}-${connectionId}`}
                x1={`${node.x}%`}
                y1={`${node.y}%`}
                x2={`${targetNode.x}%`}
                y2={`${targetNode.y}%`}
                stroke="rgba(14, 165, 233, 0.3)"
                strokeWidth="1"
                className="animate-pulse"
                style={{
                  animation: `networkPulse ${3 + Math.random() * 2}s ease-in-out infinite`,
                  animationDelay: `${Math.random() * 2}s`
                }}
              />
            );
          })
        )}
      </svg>

      {/* Neural Network Nodes */}
      {dataNodes.map((node) => (
        <div
          key={node.id}
          className="absolute w-3 h-3 bg-blue-400 rounded-full"
          style={{
            left: `${node.x}%`,
            top: `${node.y}%`,
            boxShadow: '0 0 15px rgba(14, 165, 233, 0.6)',
            animation: `nodePulse ${2 + node.pulse}s ease-in-out infinite`,
            animationDelay: `${node.pulse}s`
          }}
        />
      ))}

      {/* Binary Code Streams */}
      {binaryStreams.map((stream) => (
        <div
          key={stream.id}
          className="absolute top-0 flex flex-col text-green-400 font-mono text-xs opacity-20"
          style={{
            left: `${stream.x}%`,
            animation: `binaryFall ${stream.speed * 10}s linear infinite`,
            animationDelay: `${Math.random() * 5}s`
          }}
        >
          {stream.chars.map((char, index) => (
            <span
              key={index}
              className="block leading-4"
              style={{
                opacity: Math.max(0.1, 1 - (index * 0.05)),
                color: Math.random() > 0.9 ? '#00ff41' : '#00aa33'
              }}
            >
              {char}
            </span>
          ))}
        </div>
      ))}

      {/* Data Visualization Charts */}
      <div className="absolute top-1/4 right-1/4 w-32 h-32 opacity-10">
        <svg viewBox="0 0 100 100" className="w-full h-full">
          <defs>
            <linearGradient id="chartGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="rgba(14, 165, 233, 0.6)" />
              <stop offset="100%" stopColor="rgba(139, 92, 246, 0.6)" />
            </linearGradient>
          </defs>
          <path
            d="M10,80 Q30,20 50,40 T90,30"
            fill="none"
            stroke="url(#chartGradient)"
            strokeWidth="2"
            className="animate-pulse"
          />
          <circle cx="10" cy="80" r="2" fill="rgba(14, 165, 233, 0.8)" className="animate-ping" />
          <circle cx="30" cy="40" r="2" fill="rgba(20, 184, 166, 0.8)" className="animate-ping" style={{ animationDelay: '0.5s' }} />
          <circle cx="50" cy="60" r="2" fill="rgba(139, 92, 246, 0.8)" className="animate-ping" style={{ animationDelay: '1s' }} />
          <circle cx="70" cy="35" r="2" fill="rgba(236, 72, 153, 0.8)" className="animate-ping" style={{ animationDelay: '1.5s' }} />
          <circle cx="90" cy="30" r="2" fill="rgba(14, 165, 233, 0.8)" className="animate-ping" style={{ animationDelay: '2s' }} />
        </svg>
      </div>

      {/* Holographic Grid */}
      <div className="absolute inset-0 opacity-5">
        <div className="w-full h-full" style={{
          backgroundImage: `
            linear-gradient(rgba(14, 165, 233, 0.3) 1px, transparent 1px),
            linear-gradient(90deg, rgba(14, 165, 233, 0.3) 1px, transparent 1px)
          `,
          backgroundSize: '50px 50px',
          animation: 'gridMove 20s linear infinite'
        }} />
      </div>

      {/* Gradient Orbs with Data Theme */}
      <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-gradient-to-r from-blue-500/10 to-cyan-500/10 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute top-3/4 right-1/4 w-96 h-96 bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }}></div>
      <div className="absolute top-1/2 left-1/2 w-48 h-48 bg-gradient-to-r from-teal-500/10 to-green-500/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '4s' }}></div>

      {/* AI Brain Visualization */}
      <div className="absolute bottom-1/4 left-1/4 w-40 h-40 opacity-10">
        <svg viewBox="0 0 100 100" className="w-full h-full">
          <circle cx="50" cy="50" r="40" fill="none" stroke="rgba(14, 165, 233, 0.4)" strokeWidth="1" className="animate-spin" style={{ animationDuration: '20s' }} />
          <circle cx="50" cy="50" r="30" fill="none" stroke="rgba(20, 184, 166, 0.4)" strokeWidth="1" className="animate-spin" style={{ animationDuration: '15s', animationDirection: 'reverse' }} />
          <circle cx="50" cy="50" r="20" fill="none" stroke="rgba(139, 92, 246, 0.4)" strokeWidth="1" className="animate-spin" style={{ animationDuration: '10s' }} />
          <circle cx="50" cy="50" r="3" fill="rgba(14, 165, 233, 0.6)" className="animate-pulse" />
        </svg>
      </div>

      <style jsx>{`
        @keyframes float3D {
          0% {
            transform: translateY(100vh) translateX(0) rotateX(0deg) rotateY(0deg) rotateZ(0deg);
          }
          25% {
            transform: translateY(75vh) translateX(20px) rotateX(90deg) rotateY(90deg) rotateZ(90deg);
          }
          50% {
            transform: translateY(50vh) translateX(-10px) rotateX(180deg) rotateY(180deg) rotateZ(180deg);
          }
          75% {
            transform: translateY(25vh) translateX(15px) rotateX(270deg) rotateY(270deg) rotateZ(270deg);
          }
          100% {
            transform: translateY(-100px) translateX(0) rotateX(360deg) rotateY(360deg) rotateZ(360deg);
          }
        }

        @keyframes rotate3D {
          0% {
            transform: rotateX(0deg) rotateY(0deg) rotateZ(0deg);
          }
          100% {
            transform: rotateX(360deg) rotateY(360deg) rotateZ(360deg);
          }
        }

        @keyframes networkPulse {
          0%, 100% {
            stroke-opacity: 0.2;
            stroke-width: 1;
          }
          50% {
            stroke-opacity: 0.8;
            stroke-width: 2;
          }
        }

        @keyframes nodePulse {
          0%, 100% {
            transform: scale(1);
            box-shadow: 0 0 15px rgba(14, 165, 233, 0.6);
          }
          50% {
            transform: scale(1.5);
            box-shadow: 0 0 25px rgba(14, 165, 233, 1);
          }
        }

        @keyframes binaryFall {
          0% {
            transform: translateY(-100vh);
          }
          100% {
            transform: translateY(100vh);
          }
        }

        @keyframes gridMove {
          0% {
            transform: translate(0, 0);
          }
          100% {
            transform: translate(50px, 50px);
          }
        }
      `}</style>
    </div>
  );
};

export default FloatingElements;