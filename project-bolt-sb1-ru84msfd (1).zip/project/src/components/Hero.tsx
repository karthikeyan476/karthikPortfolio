import React from 'react';
import { MapPin, Mail, Phone } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center pt-20 pb-20">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          {/* Profile Image */}
          <div className="mb-8 relative inline-block">
            <div className="w-40 h-40 mx-auto rounded-full bg-gradient-to-r from-blue-500 to-purple-600 p-1">
              <div className="w-full h-full rounded-full overflow-hidden bg-slate-800">
                <img 
                  src="/Karthik - Copy.jpg" 
                  alt="Karthikeyan Subramanian" 
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
            <div className="absolute -top-2 -right-2 w-6 h-6 bg-green-500 rounded-full border-4 border-slate-900"></div>
          </div>

          {/* Name and Title */}
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-4 bg-gradient-to-r from-blue-400 via-purple-500 to-teal-400 bg-clip-text text-transparent">
            Karthikeyan Subramanian
          </h1>
          <h2 className="text-xl md:text-2xl text-gray-300 mb-8 font-bold">
            Senior Data Analyst | Data Engineer | BI Specialist
          </h2>

          {/* Description */}
          <p className="text-base text-gray-400 mb-8 max-w-3xl mx-auto leading-relaxed">
            I'm a passionate and results-oriented BI and Data Analytics professional with 5+ years of experience delivering enterprise data solutions across healthcare, finance, procurement, and infrastructure sectors. I specialize in Power BI, SQL, and Azure Data Factory—building pipelines and dashboards that deliver strategic insights and drive measurable business outcomes.
          </p>

          {/* Contact Info Tabs */}
          <div className="flex justify-center mb-8">
            <div className="flex bg-white/5 backdrop-blur-sm rounded-full p-2 border border-white/10">
              <div className="flex items-center gap-2 px-6 py-3 text-gray-300 hover:text-white transition-colors">
                <MapPin className="w-5 h-5 text-blue-400" />
                <span>Australia</span>
              </div>
              <div className="flex items-center gap-2 px-6 py-3 text-gray-300 hover:text-white transition-colors border-l border-white/10">
                <Mail className="w-5 h-5 text-blue-400" />
                <span>karthi.s.427@gmail.com</span>
              </div>
              <div className="flex items-center gap-2 px-6 py-3 text-gray-300 hover:text-white transition-colors border-l border-white/10">
                <Phone className="w-5 h-5 text-blue-400" />
                <span>+61451222731</span>
              </div>
            </div>
          </div>

          {/* CTA Button - Centered */}
          <div className="flex justify-center">
            <button 
              onClick={() => document.getElementById('projects')?.scrollIntoView({ behavior: 'smooth' })}
              className="px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-full font-semibold shadow-lg shadow-blue-500/25 hover:shadow-xl hover:shadow-blue-500/40 transition-all duration-300 transform hover:scale-105"
            >
              View My Work
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;