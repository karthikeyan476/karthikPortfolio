import React, { useState } from 'react';
import { Brain, MessageSquare, Calculator, Presentation, Search } from 'lucide-react';

const AITools: React.FC = () => {
  const [activeAITool, setActiveAITool] = useState('chatgpt');

  const aiTools = [
    {
      id: 'chatgpt',
      name: 'ChatGPT',
      icon: MessageSquare,
      description: 'Advanced conversational AI for data analysis, code generation, and business intelligence insights',
      capabilities: [
        'Data Analysis Automation',
        'SQL Query Generation',
        'Report Writing & Documentation',
        'Code Debugging & Optimization',
        'Business Intelligence Insights'
      ],
      color: 'from-green-500 to-emerald-600'
    },
    {
      id: 'claude',
      name: 'Claude AI',
      icon: Brain,
      description: 'Sophisticated AI assistant for complex data reasoning, analysis, and strategic decision-making',
      capabilities: [
        'Complex Data Reasoning',
        'Strategic Analysis',
        'Technical Documentation',
        'Data Interpretation',
        'Process Optimization'
      ],
      color: 'from-orange-500 to-red-600'
    },
    {
      id: 'quadratic',
      name: 'Quadratic AI',
      icon: Calculator,
      description: 'AI-powered spreadsheet tool for advanced data manipulation and computational analysis',
      capabilities: [
        'Advanced Spreadsheet Analytics',
        'Python Integration',
        'Data Visualization',
        'Computational Analysis',
        'Automated Calculations'
      ],
      color: 'from-blue-500 to-indigo-600'
    },
    {
      id: 'gamma',
      name: 'Gamma',
      icon: Presentation,
      description: 'AI presentation generator for creating compelling data stories and executive dashboards',
      capabilities: [
        'Automated Presentation Creation',
        'Data Storytelling',
        'Visual Design Generation',
        'Executive Reporting',
        'Interactive Dashboards'
      ],
      color: 'from-purple-500 to-pink-600'
    },
    {
      id: 'perplexity',
      name: 'Perplexity.ai',
      icon: Search,
      description: 'AI-powered research engine for data insights, market analysis, and trend identification',
      capabilities: [
        'Real-time Research',
        'Market Analysis',
        'Trend Identification',
        'Data Source Verification',
        'Competitive Intelligence'
      ],
      color: 'from-teal-500 to-cyan-600'
    }
  ];

  const activeToolData = aiTools.find(tool => tool.id === activeAITool);

  return (
    <section id="ai-tools" className="py-20 relative">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Hands-On AI Tools with Prompt Engineering
          </h2>
          <p className="text-base text-gray-400 max-w-3xl mx-auto">
            Leveraging cutting-edge AI technologies to enhance data analysis, automate workflows, and deliver intelligent insights
          </p>
        </div>

        {/* AI Tools Horizontal Tabs */}
        <div className="flex justify-center mb-12">
          <div className="flex flex-wrap justify-center bg-white/5 backdrop-blur-sm rounded-2xl p-3 border border-white/10 gap-2">
            {aiTools.map((tool) => {
              const IconComponent = tool.icon;
              return (
                <button
                  key={tool.id}
                  onClick={() => setActiveAITool(tool.id)}
                  className={`flex items-center gap-2 px-4 py-3 rounded-xl transition-all duration-300 ${
                    activeAITool === tool.id
                      ? `bg-gradient-to-r ${tool.color} text-white shadow-lg transform scale-105`
                      : 'text-gray-400 hover:text-white hover:bg-white/10'
                  }`}
                >
                  <IconComponent className="w-5 h-5" />
                  <span className="font-medium text-sm sm:text-base">{tool.name}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Active Tool Details */}
        {activeToolData && (
          <div className="max-w-4xl mx-auto">
            <div className="group relative">
              <div className={`absolute inset-0 bg-gradient-to-r ${activeToolData.color} opacity-20 rounded-2xl blur-xl group-hover:opacity-30 transition-opacity duration-500`}></div>
              <div className="relative backdrop-blur-sm bg-white/5 border border-white/10 rounded-2xl p-8 hover:bg-white/10 transition-all duration-300 hover:border-blue-400/30 hover:shadow-xl hover:shadow-blue-500/10">
                <div className="flex items-center mb-6">
                  <div className={`w-16 h-16 bg-gradient-to-r ${activeToolData.color} rounded-2xl flex items-center justify-center mr-6 group-hover:scale-110 transition-transform duration-300`}>
                    <activeToolData.icon className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-2">{activeToolData.name}</h3>
                    <p className="text-base text-gray-400 leading-relaxed">{activeToolData.description}</p>
                  </div>
                </div>

                <div>
                  <h4 className="text-lg font-semibold text-white mb-4">Key Capabilities & Applications</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {activeToolData.capabilities.map((capability, index) => (
                      <div
                        key={index}
                        className="flex items-center p-4 bg-white/5 rounded-lg border border-white/10 hover:bg-white/10 transition-all duration-300"
                      >
                        <div className={`w-2 h-2 bg-gradient-to-r ${activeToolData.color} rounded-full mr-3 flex-shrink-0`}></div>
                        <span className="text-sm text-gray-300 group-hover:text-white transition-colors duration-300">{capability}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-8 p-6 bg-gradient-to-r from-blue-600/10 to-purple-600/10 rounded-xl border border-blue-500/20">
                  <h4 className="text-base font-semibold text-white mb-2">Prompt Engineering Expertise</h4>
                  <p className="text-sm text-gray-300 leading-relaxed">
                    Skilled in crafting precise, context-aware prompts to maximize AI tool effectiveness for data analysis, 
                    report generation, and business intelligence tasks. Experienced in iterative prompt refinement and 
                    multi-step reasoning approaches to achieve optimal results.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default AITools;