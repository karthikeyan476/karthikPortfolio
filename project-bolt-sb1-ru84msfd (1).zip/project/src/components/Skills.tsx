import React from 'react';
import { BarChart3, Database, Cloud, Code, Zap, Users } from 'lucide-react';

const Skills: React.FC = () => {
  const skillCategories = [
    {
      icon: BarChart3,
      title: 'Business Intelligence',
      skills: ['Power BI (DAX, Data Modelling, RLS)', 'Tableau & Tableau Prep (RLS, Administrator)', 'Report Automation / Scheduling']
    },
    {
      icon: Database,
      title: 'Data Engineering',
      skills: ['Azure Data Factory & Databricks', 'SQL Server, PostgreSQL, Oracle', 'ETL/ELT Processes', 'Data Warehousing', 'Data Pipeline Design']
    },
    {
      icon: Cloud,
      title: 'Cloud Platforms',
      skills: ['Microsoft Azure (Data Factory, Data Lake)', 'AWS Services (S3, EC2, Redshift)']
    },
    {
      icon: Code,
      title: 'Programming & Analytics',
      skills: ['Python (Pandas, NumPy, Matplotlib)', 'SQL Optimization']
    },
    {
      icon: Zap,
      title: 'Analytics Tools',
      skills: ['Advanced Excel', 'Google Analytics', 'Data Profiling', 'Data Cleansing', 'Data Wrangling', 'Dynamics 365']
    },
    {
      icon: Users,
      title: 'Professional Skills',
      skills: ['Agile Methodology', 'Stakeholder Management', 'Data Storytelling', 'Client Consulting', 'Project Leadership']
    }
  ];

  return (
    <section id="skills" className="py-20 relative">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Technical Expertise
          </h2>
          <p className="text-base text-gray-400 max-w-2xl mx-auto">
            Comprehensive skill set spanning the entire data lifecycle, from collection to actionable insights
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skillCategories.map((category, index) => {
            const IconComponent = category.icon;
            return (
              <div
                key={index}
                className="group relative h-full"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                <div className="relative backdrop-blur-sm bg-white/5 border border-white/10 rounded-2xl p-8 hover:bg-white/10 transition-all duration-300 hover:border-blue-400/30 hover:shadow-xl hover:shadow-blue-500/10 h-full flex flex-col">
                  <div className="flex items-center mb-6">
                    <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl flex items-center justify-center mr-4 group-hover:scale-110 transition-transform duration-300">
                      <IconComponent className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-lg font-semibold text-white">{category.title}</h3>
                  </div>
                  <div className="flex-1">
                    <ul className="space-y-3 h-full flex flex-col justify-start">
                      {category.skills.map((skill, skillIndex) => (
                        <li key={skillIndex} className="flex items-start text-sm text-gray-300 group-hover:text-white transition-colors duration-300">
                          <div className="w-2 h-2 bg-blue-400 rounded-full mr-3 opacity-60 group-hover:opacity-100 mt-2 flex-shrink-0"></div>
                          <span className="leading-relaxed">{skill}</span>
                        </li>
                      ))}
                      {/* Add empty space to maintain consistent height */}
                      {Array.from({ length: Math.max(0, 6 - category.skills.length) }).map((_, emptyIndex) => (
                        <li key={`empty-${emptyIndex}`} className="h-6"></li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Skills;