import React from 'react';
import { Download, Briefcase, GraduationCap } from 'lucide-react';

const Resume: React.FC = () => {
  const experience = [
    {
      title: 'Senior Data Engineer',
      company: 'CitiusTech Healthcare Technology – India',
      period: 'Feb 2024 – Apr 2025',
      achievements: [
        'Led healthcare analytics initiatives that boosted campaign performance by 18.5% and patient engagement by 12%.',
        'Designed executive-level Power BI dashboards with RLS and DAX, cutting campaign costs by 15%.',
        'Built ETL pipelines using Azure Data Factory, Databricks, and Google Analytics for 10+ TB data processing.'
      ]
    },
    {
      title: 'Senior Data Analyst',
      company: 'Bilight Solution Pty Ltd – India',
      period: 'May 2023 – Dec 2023',
      achievements: [
        'Built executive dashboards in Tableau and Power BI that improved data visualization efficiency by 30%.',
        'Enabled secure insights with Power BI Row-Level Security and optimized reporting time by 25% using DAX.',
        'Streamlined banking data into centralized warehouses, cutting manual integration by 40%.'
      ]
    },
    {
      title: 'Data and Reporting Analyst',
      company: 'OnTheLine – Melbourne, Australia',
      period: 'Jul 2022 – Apr 2023',
      achievements: [
        'Led the full design and rollout of scalable reporting for a not-for-profit mental health call centre.',
        'Created real-time Power BI and Tableau dashboards, boosting reporting efficiency by 19%.',
        'Used SQL and CRM data to drive insights, improving data quality validation by 20% and accuracy by 25%.'
      ]
    },
    {
      title: 'Data Visualisation Expert',
      company: 'Bilight Solution Pty Ltd – India',
      period: 'Jan 2021 – May 2022',
      achievements: [
        'Led end-to-end BI initiatives across infrastructure and finance, raising stakeholder satisfaction by 20%.',
        'Built over 40 dashboards in Power BI and Tableau, reducing revenue leakage by 95%.',
        'Developed ETL pipelines using AWS Glue and Redshift, integrating 11 data sources for fast, reliable reporting.'
      ]
    },
    {
      title: 'Data Analyst',
      company: 'Purchasing Index Pty Ltd – Melbourne, Australia',
      period: 'Jul 2019 – Mar 2020',
      achievements: [
        'Built Tableau and Power BI dashboards that optimized category spend by 22% and supported cost-saving initiatives.',
        'Improved data accuracy by 25% through ETL workflows in KNIME and SQL Server.',
        'Enhanced self-service analytics and data storytelling using advanced Tableau visualizations.'
      ]
    },
    {
      title: 'Product Analyst',
      company: 'Sybase Solution – India',
      period: 'Nov 2015 – Jun 2016',
      achievements: [
        'Supported product development with insights from market research, customer feedback, and KPI tracking in Tableau.',
        'Used SQL and Excel to analyze performance data and identify opportunities for product improvement.'
      ]
    }
  ];

  const handleDownloadResume = () => {
    window.open('https://drive.google.com/file/d/1slxlvneMo0PnAyjlmsFa8A00fQjH-K5R/view?usp=sharing', '_blank');
  };

  return (
    <section id="resume" className="py-20 relative">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Professional Background
          </h2>
          <p className="text-base text-gray-400 max-w-2xl mx-auto">
            5 years of experience delivering data-driven solutions across multiple industries
          </p>
        </div>

        <div className="max-w-7xl mx-auto">
          {/* Download Resume Button */}
          <div className="text-center mb-16">
            <button 
              onClick={handleDownloadResume}
              className="inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-full font-semibold shadow-lg shadow-blue-500/25 hover:shadow-xl hover:shadow-blue-500/40 transition-all duration-300 transform hover:scale-105"
            >
              <Download className="w-5 h-5" />
              Download Full Resume
            </button>
          </div>

          {/* Experience Section */}
          <div className="mb-20">
            <div className="flex items-center justify-center gap-3 mb-12">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                <Briefcase className="w-5 h-5 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-white">Experience</h3>
            </div>

            {/* Experience Grid - 3 per row */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {experience.map((job, index) => (
                <div key={index} className="group relative h-full">
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                  <div className="relative backdrop-blur-sm bg-white/5 border border-white/10 rounded-xl p-6 hover:bg-white/10 transition-all duration-300 hover:border-blue-400/30 hover:shadow-xl hover:shadow-blue-500/10 h-full flex flex-col">
                    <div className="flex-1">
                      <h4 className="text-base font-semibold text-white mb-2 leading-tight">{job.title}</h4>
                      <p className="text-blue-400 font-medium mb-2 text-xs">{job.company}</p>
                      <p className="text-gray-400 text-xs mb-3">{job.period}</p>
                      <ul className="space-y-2 flex-1">
                        {job.achievements.map((achievement, achievementIndex) => (
                          <li key={achievementIndex} className="text-gray-300 text-xs leading-relaxed flex items-start text-xs">
                            <div className="w-1 h-1 bg-blue-400 rounded-full mt-1.5 mr-2 flex-shrink-0"></div>
                            {achievement}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Education Section */}
          <div>
            <div className="flex items-center justify-center gap-3 mb-12">
              <div className="w-10 h-10 bg-gradient-to-r from-teal-500 to-blue-600 rounded-lg flex items-center justify-center">
                <GraduationCap className="w-5 h-5 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-white">Education</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              <div className="group relative">
                <div className="absolute inset-0 bg-gradient-to-r from-teal-600/20 to-blue-600/20 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                <div className="relative backdrop-blur-sm bg-white/5 border border-white/10 rounded-xl p-8 hover:bg-white/10 transition-all duration-300 hover:border-teal-400/30 hover:shadow-xl hover:shadow-teal-500/10">
                  <h4 className="text-lg font-semibold text-white mb-2">Master of Information Technology</h4>
                  <p className="text-teal-400 font-medium mb-2 text-sm">Swinburne University of Technology</p>
                  <p className="text-gray-400 text-xs">2017 - 2019</p>
                </div>
              </div>
              
              <div className="group relative">
                <div className="absolute inset-0 bg-gradient-to-r from-teal-600/20 to-blue-600/20 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                <div className="relative backdrop-blur-sm bg-white/5 border border-white/10 rounded-xl p-8 hover:bg-white/10 transition-all duration-300 hover:border-teal-400/30 hover:shadow-xl hover:shadow-teal-500/10">
                  <h4 className="text-lg font-semibold text-white mb-2">Bachelor of Information Technology</h4>
                  <p className="text-teal-400 font-medium mb-2 text-sm">Anna University</p>
                  <p className="text-gray-400 text-xs">2011 - 2015</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Resume;