import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Skills from './components/Skills';
import Projects from './components/Projects';
import AITools from './components/AITools';
import Resume from './components/Resume';
import Contact from './components/Contact';
import FloatingElements from './components/FloatingElements';

function App() {
  return (
    <div className="relative min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 overflow-x-hidden">
      <FloatingElements />
      
      {/* Additional AI/Data themed background layers */}
      <div className="fixed inset-0 pointer-events-none">
        {/* Matrix-style background pattern */}
        <div className="absolute inset-0 opacity-5">
          <div 
            className="w-full h-full"
            style={{
              backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%2300bcd4' fill-opacity='0.1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
              animation: 'matrixScroll 30s linear infinite'
            }}
          />
        </div>

        {/* Circuit board pattern */}
        <div className="absolute top-0 right-0 w-1/3 h-full opacity-10">
          <svg className="w-full h-full" viewBox="0 0 400 800">
            <defs>
              <pattern id="circuit" x="0" y="0" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M20 0v40M0 20h40" stroke="rgba(14, 165, 233, 0.3)" strokeWidth="0.5" fill="none"/>
                <circle cx="20" cy="20" r="2" fill="rgba(14, 165, 233, 0.4)"/>
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#circuit)"/>
          </svg>
        </div>

        {/* Data flow lines */}
        <div className="absolute inset-0">
          <svg className="w-full h-full" viewBox="0 0 1920 1080">
            <defs>
              <linearGradient id="dataFlow" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="rgba(14, 165, 233, 0)" />
                <stop offset="50%" stopColor="rgba(14, 165, 233, 0.6)" />
                <stop offset="100%" stopColor="rgba(14, 165, 233, 0)" />
              </linearGradient>
            </defs>
            
            <path d="M0,200 Q480,100 960,200 T1920,200" 
                  fill="none" 
                  stroke="url(#dataFlow)" 
                  strokeWidth="2"
                  className="opacity-30">
              <animate attributeName="stroke-dasharray" 
                       values="0,1000;1000,0;0,1000" 
                       dur="8s" 
                       repeatCount="indefinite"/>
            </path>
            
            <path d="M0,400 Q480,500 960,400 T1920,400" 
                  fill="none" 
                  stroke="url(#dataFlow)" 
                  strokeWidth="2"
                  className="opacity-20">
              <animate attributeName="stroke-dasharray" 
                       values="1000,0;0,1000;1000,0" 
                       dur="10s" 
                       repeatCount="indefinite"/>
            </path>
            
            <path d="M0,600 Q480,700 960,600 T1920,600" 
                  fill="none" 
                  stroke="url(#dataFlow)" 
                  strokeWidth="2"
                  className="opacity-25">
              <animate attributeName="stroke-dasharray" 
                       values="500,500;0,1000;500,500" 
                       dur="12s" 
                       repeatCount="indefinite"/>
            </path>
          </svg>
        </div>
      </div>

      <Header />
      <main>
        <Hero />
        <Skills />
        <Projects />
        <AITools />
        <Resume />
      </main>

      <style jsx>{`
        @keyframes matrixScroll {
          0% {
            transform: translateY(0);
          }
          100% {
            transform: translateY(60px);
          }
        }
      `}</style>
    </div>
  );
}

export default App;